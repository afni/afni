v1.0

These are still in testing phase, as is the online documentation!

++ v2.3 (Sept, 2016b):
   o fat_pre_axialize_anat.tcsh   :added ability to warp easily to refset
-------------------------------------------------------------------------
++ v2.2.1 (Sept, 2016):
   o fat_proc_decmap.tcsh         :new program;
                                   calculate RGB-coloration maps of DT
                                   directionality, weighted by FA.
-------------------------------------------------------------------------
++ v2.2 (Sept, 2016):
   o fat_pre_axialize_anat.tcsh   :added L-R symmetry parts (pre-symm as 
                                   ON by default);
                                   can specify working dir;
                                   cmass->(0,0,0) as def for output.
-------------------------------------------------------------------------
++ v2.1 (Aug, 2016):
   o fat_pre_convert*             :Make volume center of mass (0,0,0) 
                                   coordinate.
   o fat_pre_axialize_anat.tcsh   :Update axializing, new options.
-------------------------------------------------------------------------
++ v2.0 (Aug, 2016):
   o Original online version!
   o These are still in testing phase, as is the online documentation.
-------------------------------------------------------------------------
